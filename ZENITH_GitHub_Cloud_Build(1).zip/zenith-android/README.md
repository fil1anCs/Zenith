# ZENITH — native Android foundation (Kotlin)

This is the first native Android project for the supplied `ZENITH_v13_social.html` source.
It is a real Kotlin/Jetpack Compose Android app foundation, not a WebView wrapper.

## Open and run

1. Install Android Studio (a recent stable release) and Android SDK Platform 35.
2. Open this folder (`zenith-android`) in Android Studio.
3. Let Gradle sync and install the requested SDK/build tools.
4. Connect an Android device with USB debugging enabled, or start an emulator.
5. Press **Run**. To create an APK, choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

The project uses JDK 17, Android Gradle Plugin 8.7.3, Kotlin 2.0.21, Compose, Room, DataStore and AndroidX Media3.

## Implemented in this starter

- Native Compose interface with a black / graphite ZENITH visual base.
- Adaptive navigation: side navigation on wide screens and bottom navigation on narrow screens.
- Local audio import using Android's document picker; selected content URIs are persisted where the provider allows it.
- Local track catalog stored in Room.
- Local like state stored in Room.
- Media3 ExoPlayer in a `MediaSessionService` for background playback and Android media controls.
- Full-screen native player with seek bar, elapsed / total time, previous / next, play / pause, shuffle, three repeat modes and playback speed (0.5×–2×).
- Native system equalizer attached to the Media3 audio session, with per-band controls, enable/disable and reset. Device/audio-route support may vary.
- Animated in-player visualizer bars that react to playback state (decorative animation; not an audio-spectrum analyzer).
- Sleep timer with 5, 10, 15, 30, 45 and 60 minute presets, plus cancellation.
- LRCLIB lyric lookup using track title, artist and duration; displays synced LRC or plain lyric text when available.
- Queue display and queue-item selection; selecting a track starts the complete local library queue at that track.
- Optional muted video cover in the full-screen player, looped and clipped to 7 seconds; URI permission is persisted and the Room database is migrated without deleting the existing library.
- DataStore preferences model for theme, accent, gapless playback, normalization, volume and sync toggle.
- A sync queue table and cloud-sync boundary, designed for offline-first operation.

## Hybrid sync status — important

The HTML source stores its app data in browser IndexedDB / LocalStorage and uses Google Identity Services for optional Google sign-in. It does **not** contain a production cloud API or a server-side account database. Supabase is now the selected backend; see the setup instructions below. The app remains offline-first and keeps local music files on-device.

## Source-to-native migration status

| Original ZENITH feature | Native project status |
|---|---|
| Home / search / library navigation | Basic native shell implemented |
| Import audio files and folders | Multi-file audio picker implemented; folder grouping and metadata enrichment pending |
| Playback, background audio, lock-screen controls | Media3 service foundation implemented |
| Playlists and queue | Queue UI and queue-item selection implemented; playlist editor still pending |
| Likes / saved tracks | Local like field implemented; full social counters and saved-track model pending |
| Lyrics (LRCLIB) | Basic lookup and display implemented; timed line-by-line synchronization and cache pending |
| Artwork lookup (iTunes / Deezer) | Pending native API clients and cache |
| Video covers (up to 7 seconds) | Native muted 7-second looping video renderer and per-track URI storage implemented |
| Speed, repeat, shuffle | Implemented; equalizer, animated visualizer and sleep timer added in this milestone |
| Profiles, follows, comments, moderation | Pending backend schema, authentication and access-control rules |
| Google sign-in | Pending Android OAuth / Credential Manager configuration |
| Backup / restore and library transfer | Pending native archive format and import/export screens |
| Settings and appearance presets | DataStore model started; settings UI pending |

## Important migration/security note

The original HTML includes a privileged account record and browser-side password-hash logic. That model must not be copied as an authoritative admin system into an APK: APK contents can be inspected and modified. Admin roles, moderation permissions, account recovery and social ownership must be enforced by the server. Passwords should be handled by a trusted identity provider or securely configured backend, never hard-coded into the Android client.

## Next development milestones

1. Finish local library: metadata extraction, folders, playlists, queue, liked/saved tracks and playback persistence.
2. Finish the player experience: equalizer, visualizer, sleep timer, lyrics, artwork lookup and audio-focus / edge-case testing.
3. Complete bidirectional Supabase sync, conflict resolution and portable track identity.
4. Finish cloud playlist, likes, follows, comments, avatar storage and profile screens.
5. Add Google sign-in, password recovery, moderation workflows and trusted admin authorization.
6. Port the remaining settings and test portrait / landscape layouts on phone and tablet; then build and test a signed release APK.

## Supabase cloud foundation (configured as the selected backend)

The project now includes a Supabase Auth / PostgREST foundation:

- Email + password registration and sign-in through Supabase Auth.
- Session tokens encrypted with AES-GCM using an Android Keystore key.
- Automatic refresh-token exchange before protected requests.
- Profile creation and profile lookup.
- Supabase REST helpers for owner-scoped upsert/delete operations.
- An offline sync worker that sends explicitly queued JSON mutations only when online and authenticated; it removes queue entries only after the server accepts them.
- SQL schema and Row Level Security policies for profiles, playlists, playlist tracks, follows, likes and comments.

### Connect your Supabase project

1. Create a project at https://supabase.com/.
2. Open **Project Settings → API** and copy the Project URL and the public anon/publishable key.
3. Copy `local.properties.example` to `local.properties` (the real file is git-ignored) and fill in:

   ```properties
   supabase.url=https://YOUR_PROJECT_REF.supabase.co
   supabase.anonKey=YOUR_PUBLIC_ANON_OR_PUBLISHABLE_KEY
   ```

4. In the Supabase SQL Editor, run `supabase/migrations/001_zenith_schema.sql`.
5. In Android Studio, sync Gradle and rebuild the app. The Settings screen contains the account panel.

Use only the public anon/publishable key in the Android app. Never use the `service_role` / secret key in an APK. RLS is mandatory and remains the security boundary. For the first test, configure Supabase Auth email confirmation according to your preference; the current first-pass registration expects Supabase to return an authenticated session immediately (email auto-confirm enabled). A full confirmation-code / deep-link recovery flow remains to be added.

### Cloud scope in this milestone

Auth, encrypted session storage, profile bootstrap, SQL schema and a push-only queue transport are implemented as the cloud foundation. Full bidirectional reconciliation, conflict resolution, profile editing, avatars/storage buckets, comments/follows/likes screens, moderation tooling and admin role management are not yet complete. The current local track URIs are device-specific; only portable metadata and user-owned cloud records should be synced, never raw local content URIs as playable cloud tracks.


## Player milestone update

The native player milestone now includes a full-screen playback surface, seek control, elapsed and total time, previous / next, shuffle, repeat off / all / one, playback speed presets (0.5×, 0.75×, 1×, 1.25×, 1.5×, 1.75×, 2×), and a visible playback queue. Video covers can be selected per track from the full-screen player; videos longer than 7 seconds are rejected, playback is muted, and the clip loops while the full-screen player is visible. The Room database version 1 → 2 migration adds the video-cover URI without clearing existing tracks.

This is still a development milestone, not a verified release build. The environment used to prepare this archive does not include Android SDK / Gradle, so the project has not been compiled or run on a device here. The LRCLIB lookup requires internet access. Equalizer availability depends on the device and active audio route; the visualizer currently uses an animated display rather than microphone/audio capture.


## Player milestone v3

- LRCLIB timed lyrics (`syncedLyrics`) are parsed into timestamped lines; the currently active line is highlighted and the list follows playback position. Plain-text lyrics remain supported as a fallback.
- Album artwork lookup uses the public iTunes Search API, scores results against local artist/title/album metadata, and stores the selected artwork URL in Room. Artwork appears in the mini-player and full-screen player.
- Room migration 2 → 3 adds the nullable `artworkUrl` field without deleting existing tracks.
- Coil Compose is used to load and cache artwork images.

Artwork lookup is user-triggered from the full-screen player and requires internet access. Results depend on iTunes catalog matching; no match is reported rather than selecting a random image.

## Build an APK in GitHub Actions (no Android Studio or local Gradle needed)

This repository includes `.github/workflows/build-apk.yml`. After uploading the project to a GitHub repository:

1. Open the repository on GitHub.
2. Open the **Actions** tab and select **Build ZENITH APK**.
3. Press **Run workflow** (or wait for the first push build to finish).
4. Open the completed workflow run and download the **ZENITH-debug-APK** artifact.
5. Extract the downloaded artifact ZIP on the Android device and install the APK.

The workflow builds a debug APK using GitHub-hosted runners. No Android Studio, Android SDK or Gradle installation is required on the user's device. This workflow has been prepared but has not yet been executed against this repository; the first GitHub run will reveal any build errors. Supabase credentials are optional for compiling and can be configured later; never add a Supabase service-role key to the app or repository.
